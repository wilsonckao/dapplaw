
const key = "6135e48d5f2421d0f5da";
const secret = "9fe0ba846ead48c51a8385b18736daaefa9e7228184baa3705e5b78218788345";
const FormData = require('form-data');


const axios = require('axios');

export const pinJSONToIPFS = async(JSONBody: any) => {
    const url = `https://api.pinata.cloud/pinning/pinJSONToIPFS`;
    //making axios POST request to Pinata ⬇️
    return axios 
        .post(url, JSONBody, {
            headers: {
                pinata_api_key: key,
                pinata_secret_api_key: secret,
            }
        })
        .then(function (response: { data: { IpfsHash: string; }; }) {
           return response.data.IpfsHash;
        })
        .catch(function (error: { message: any; }) {
            console.log(error)
            // return {
            //     success: false,
            //     message: error.message,
            // }

    });
};


export const pinFileToIPFS = async (file:any) => {
    try {

        const formData = new FormData();
        formData.append("file", file);
    
        const resFile = await axios({
          method: "post",
          url: "https://api.pinata.cloud/pinning/pinFileToIPFS",
          data: formData,
          headers: {
            'pinata_api_key': key,
            'pinata_secret_api_key': secret,
            "Content-Type": "multipart/form-data"
          },
        });
    
        return resFile.data.IpfsHash;
    } catch (err) {
        console.log(err);
    }
}
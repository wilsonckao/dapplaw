// @ts-nocheck
import { type } from "os";
import { SetStateAction, useEffect, useState } from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { pinFileToIPFS, pinJSONToIPFS } from '../utils/pinata'



export default function Home() {

  //State variables
  const [walletAddress, setWallet] = useState("");
  const [recipientAddress, SetRecipientAddress] = useState("");
  const [status, setStatus] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [uri, setUri] = useState("");

  const [uploadedFile, setUploadedFile] = useState();

  const [isLoading, setIsLoading] = useState(false);

  // input handlers

  const handleName = (event) => {
    setName(event.target.value);
  }

  const handleAddress = (event) => {
    SetRecipientAddress(event.target.value);
  }

  // wallet Connection

  const connectMetamask = async () => {
    if (window.ethereum) {
      try {
        const addressArray = await window.ethereum.request({
          method: "eth_requestAccounts"
        });
        setWallet(addressArray[0]);

        toast.success('Metamask Connected!', {
          position: "bottom-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",
        });

      } catch (err) {
        console.log(err);
      }
    } else {
      console.log("Please install metmask.");
      toast.error('Install Metamask', {
        position: "bottom-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
    }
  }

  const getCurrentWalletConnected = async () => {
    if (window.ethereum) {
      try {
        const addressArray = await window.ethereum.request({
          method: "eth_accounts"
        });
        setWallet(addressArray[0]);
      } catch (err) {
        console.log(err);
      }
    } else {
      console.log("Please install metmask.");
    }
  }

  const addWalletListner = async () => {
    if (window.ethereum) {
      window.ethereum.on("accountsChanged", (accounts: string | any[]) => {
        if (accounts.length > 0) {
          setWallet(accounts[0]);
        }
      })
    }
  }

  useEffect(() => {
    getCurrentWalletConnected();
    addWalletListner();
  }, [])

  // mint related 

  // const alchemyKey = "https://eth-sepolia.g.alchemy.com/v2/zs5eoovuHo-OOvW2Lg4ocWJYgj0sDoEk";
  const alchemyKey = "https://eth-goerli.g.alchemy.com/v2/zcV3855tDu1lev1bCk6MwwZsAqMcYDQo";
  const { createAlchemyWeb3 } = require("@alch/alchemy-web3");
  const web3 = createAlchemyWeb3(alchemyKey);

  const contractABI = require('../../contract-abi.json')
  // const contractAddress = "0x176E7d0506272e4FC80aC914e9B80536C8345Dc3";
  const contractAddress = "0x0323F37C60d24842195F2720deAd6abC2a639797";

  // goerly addres 0x0323F37C60d24842195F2720deAd6abC2a639797

  const contract =  new web3.eth.Contract(contractABI, contractAddress);


  const fileHandler = async (event: { target: { files: SetStateAction<undefined>[]; }; }) => {
    setUploadedFile(event.target.files[0])
  }



  const onClickMint = async () => {
    setIsLoading(true);
    // upload file to IPFS
    const fileHash = await pinFileToIPFS(uploadedFile);

    await fileHash
    // pin JSON to ipfs
    // const metadata = new Object();
    // metadata.name = name;
    // metadata.image = `ipfs://${fileHash}/`;
    // metadata.description = name;

    const metadata = {
      "description": name,
      "image": `ipfs://${fileHash}/`,
      "name": name,
      "attributes": []
    }

    const nftURI = await pinJSONToIPFS(metadata);
    console.log(`ipfs://${nftURI}`);

    toast.success("NFT Uploaded Successfully")
    
    try {
      contract.methods.safeMint(recipientAddress, `ipfs://${nftURI}`).send({from: window.ethereum.selectedAddress}).then(() => {
        toast.success("Mint successfull 🚀");
        setIsLoading(false);
      });
    } catch (err) {
      console.log(err);
    }
    
  }

  return (
    <>
      <section className="text-gray-600 body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap justify-between gap-4">

            <div className="card__wrapper w-[24rem] p-6 text-center  rounded-lg bg-white shadow-lg">
              <h5 className="mb-2 text-xl bg-gray-100 p-2 rounded-lg  font-medium leading-tight text-neutral-800 ">
                Please Connect To Metamask
              </h5>

              {walletAddress ? <p className="mt-4">Metmask Connected.</p> : <button onClick={connectMetamask} className="w-full flex justify-center gap-x-4 items-center bg-[#44912d] text-white font-bold py-2 px-4 rounded-lg inline-flex"> Connect Metamask </button>

              }

            </div>

            <div className="card__wrapper w-[24rem] p-6 text-center  rounded-lg bg-white shadow-lg p-6">
              <h5 className="mb-2 text-xl bg-gray-100 p-2 rounded-lg  font-medium leading-tight text-neutral-800 ">
                Upload A Document To Convert It Into NFT And Give It A Name
              </h5>

              <div className="my-8">
                <input type="text" onChange={handleName} id="full-name" name="full-name" className="w-full bg-gray-100 bg-opacity-50 rounded-lg border border-gray-300 focus:border-indigo-500 focus:bg-transparent focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out mb-4" placeholder="Name" />

                <input class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none w-full bg-gray-100 bg-opacity-50 rounded-lg border border-gray-300 focus:border-indigo-500 focus:bg-transparent focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out mb-4" aria-describedby="file_input_help" id="file_input" type="file" onChange={fileHandler} />

                <input type="text" onChange={handleAddress} id="full-name" name="full-name" className="w-full bg-gray-100 bg-opacity-50 rounded-lg border border-gray-300 focus:border-indigo-500 focus:bg-transparent focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" placeholder="Recipient Address" />

              </div>

              <button onClick={onClickMint} disabled={isLoading} className="w-full flex justify-center gap-x-4 items-center bg-[#44912d] text-white font-bold py-2 px-4 rounded-lg inline-flex">{isLoading ? 'Processing ..' : 'Upload And Mint'} </button>
            </div>

            {/* <div className="card__wrapper w-[24rem] p-6 text-center  rounded-lg bg-white shadow-lg p-6">
              <h5 className="mb-2 text-xl bg-gray-100 p-2 rounded-lg  font-medium leading-tight text-neutral-800 ">
                Send NFT To An Address
              </h5>

              <div className="my-8">
                <input type="text" id="full-name" name="full-name" className="w-full bg-gray-100 bg-opacity-50 rounded-lg border border-gray-300 focus:border-indigo-500 focus:bg-transparent focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out" placeholder="Recipient Address" />
              </div>

              <button className="w-full flex justify-center gap-x-4 items-center bg-[#44912d] text-white font-bold py-2 px-4 rounded-lg inline-flex"> Send </button>
            </div> */}
          </div>
        </div>

        <ToastContainer />

      </section>
    </>
  )
}
